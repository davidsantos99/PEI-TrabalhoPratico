package xmlvalidator;

public class XMLValidator {


    public static void main(String[] args) {
        XMLManagement x1 = new XMLManagement("teste1.xml", "empresa.xsd");
        x1.validate(true);
    }
    
}
    